default_app_config = 'src.apps.users.apps.Config'
