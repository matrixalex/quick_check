default_app_config = 'src.apps.homework.apps.Config'
