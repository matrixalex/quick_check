from src.apps.core.apps import BaseConfig


class Config(BaseConfig):
    name = 'src.apps.homework'
    label = 'homework'
    verbose_name = 'Домашние работы'
